# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

class ObjectBase(tvtk_base.TVTKBase):
    r"""
    ObjectBase - abstract base class for most VTK objects
    
    ObjectBase is the base class for all reference counted classes in
    the VTK. These classes include Command classes, InformationKey
    classes, and Object classes.
    
    ObjectBase performs reference counting: objects that are reference
    counted exist as long as another object uses them. Once the last
    reference to a reference counted object is removed, the object will
    spontaneously destruct.
    
    Constructor and destructor of the subclasses of ObjectBase should
    be protected, so that only New() and un_register() actually call them.
    Debug leaks can be used to see if there are any objects left with
    nonzero reference count.
    
    @warning
    Note: Objects of subclasses of ObjectBase should always be created
    with the New() method and deleted with the Delete() method. They
    cannot be allocated off the stack (i.e., automatic objects) because
    the constructor is a protected method.
    
    @sa
    Object Command InformationKey
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkObjectBase, obj, update, **traits)
    
    reference_count = traits.Int(1, enter_set=True, auto_set=False, desc=\
        r"""
        Sets the reference count. (This is very dangerous, use with
        care.)
        """
    )

    def _reference_count_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetReferenceCount,
                        self.reference_count)

    def get_address_as_string(self, *args):
        """
        get_address_as_string(self, classname:str) -> str
        Get address of C++ object in format 'Addr=%p' after casting to
        the specified type.  This method is obsolete, you can get the
        same information from o.__this__."""
        ret = self._wrap_call(self._vtk_obj.GetAddressAsString, *args)
        return ret

    def _get_class_name(self):
        return self._vtk_obj.GetClassName()
    class_name = traits.Property(_get_class_name, desc=\
        r"""
        Return the class name as a string.
        """
    )

    def _get_is_in_memkind(self):
        return self._vtk_obj.GetIsInMemkind()
    is_in_memkind = traits.Property(_get_is_in_memkind, desc=\
        r"""
        A local state flag that remembers whether this object lives in
        the normal or extended memory space.
        """
    )

    def get_number_of_generations_from_base(self, *args):
        """
        get_number_of_generations_from_base(self, name:str) -> int
        C++: virtual IdType get_number_of_generations_from_base(
            const char *name)
        Given the name of a base class of this class type, return the
        distance of inheritance between this class type and the named
        class (how many generations of inheritance are there between this
        class and the named class). If the named class is not in this
        class's inheritance tree, return a negative value. Valid
        responses will always be nonnegative. This method works in
        combination with TypeMacro found in SetGet.h.
        """
        ret = self._wrap_call(self._vtk_obj.GetNumberOfGenerationsFromBase, *args)
        return ret

    def get_number_of_generations_from_base_type(self, *args):
        """
        get_number_of_generations_from_base_type(name:str) -> int
        C++: static IdType get_number_of_generations_from_base_type(
            const char *name)
        Given a the name of a base class of this class type, return the
        distance of inheritance between this class type and the named
        class (how many generations of inheritance are there between this
        class and the named class). If the named class is not in this
        class's inheritance tree, return a negative value. Valid
        responses will always be nonnegative. This method works in
        combination with TypeMacro found in SetGet.h.
        """
        ret = self._wrap_call(self._vtk_obj.GetNumberOfGenerationsFromBaseType, *args)
        return ret

    def _get_object_description(self):
        return self._vtk_obj.GetObjectDescription()
    object_description = traits.Property(_get_object_description, desc=\
        r"""
        The object description printed in messages and print_self output.
        To be used only for reporting purposes.
        """
    )

    def _get_using_memkind(self):
        return self._vtk_obj.GetUsingMemkind()
    using_memkind = traits.Property(_get_using_memkind, desc=\
        r"""
        A global state flag that controls whether Objects are
        constructed in the usual way (the default) or within the extended
        memory space.
        """
    )

    def fast_delete(self):
        """
        fast_delete(self) -> None
        C++: virtual void fast_delete()
        Delete a reference to this object.  This version will not invoke
        garbage collection and can potentially leak the object if it is
        part of a reference loop.  Use this method only when it is known
        that the object has another reference and would not be collected
        if a full garbage collection check were done.
        """
        ret = self._vtk_obj.FastDelete()
        return ret
        

    def initialize_object_base(self):
        """
        initialize_object_base(self) -> None
        C++: void initialize_object_base()"""
        ret = self._vtk_obj.InitializeObjectBase()
        return ret
        

    def is_a(self, *args):
        """
        is_a(self, name:str) -> int
        C++: virtual TypeBool is_a(const char *name)
        Return 1 if this class is the same type of (or a subclass of) the
        named class. Returns 0 otherwise. This method works in
        combination with TypeMacro found in SetGet.h.
        """
        ret = self._wrap_call(self._vtk_obj.IsA, *args)
        return ret

    def is_type_of(self, *args):
        """
        is_type_of(name:str) -> int
        C++: static TypeBool is_type_of(const char *name)
        Return 1 if this class type is the same type of (or a subclass
        of) the named class. Returns 0 otherwise. This method works in
        combination with TypeMacro found in SetGet.h.
        """
        ret = self._wrap_call(self._vtk_obj.IsTypeOf, *args)
        return ret

    def register(self, *args):
        """
        register(self, o:ObjectBase)
        C++: virtual void register(ObjectBase *o)
        Increase the reference count by 1.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.Register, *my_args)
        return ret

    def set_memkind_directory(self, *args):
        """
        set_memkind_directory(directoryname:str) -> None
        C++: static void set_memkind_directory(const char *directoryname)
        The name of a directory, ideally mounted -o dax, to memory map an
        extended memory space within. This must be called before any
        objects are constructed in the extended space. It can not be
        changed once setup.
        """
        ret = self._wrap_call(self._vtk_obj.SetMemkindDirectory, *args)
        return ret

    def un_register(self, *args):
        """
        un_register(self, o:ObjectBase)
        C++: virtual void un_register(ObjectBase* o)
        Decrease the reference count (release by another object). This
        has the same effect as invoking Delete() (i.e., it reduces the
        reference count by 1).
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.UnRegister, *my_args)
        return ret

    def uses_garbage_collector(self):
        """
        uses_garbage_collector(self) -> bool
        C++: virtual bool uses_garbage_collector()
        Indicate whether the class uses `vtkgarbage_collector` or not.
        
        Most classes will not need to do this, but if the class
        participates in a strongly-connected reference count cycle,
        participation can resolve these cycles.
        
        If overriding this method to return true, the `report_references`
        method should be overridden to report references that may be in
        cycles.
        """
        ret = self._vtk_obj.UsesGarbageCollector()
        return ret
        

    def override(self, *args):
        """
        This method can be used to override a VTK class with a Python subclass.
        The class type passed to override will afterwards be instantiated
        instead of the type override is called on.
        For example,
        class foo(vtk.Points):
          pass
        vtk.Points.override(foo)
        
        will lead to foo being instantied everytime Points() is called.
        The main objective of this functionality is to enable developers to
        extend VTK classes with more pythonic subclasses that contain
        convenience functionality.
        """
        ret = self._wrap_call(self._vtk_obj.override, *args)
        return ret

    _updateable_traits_ = \
    (('reference_count', 'GetReferenceCount'),)
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    ([])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(ObjectBase, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit ObjectBase properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], []),
            title='Edit ObjectBase properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit ObjectBase properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

