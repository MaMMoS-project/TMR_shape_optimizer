# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.data_object import DataObject


class CellGrid(DataObject):
    r"""
    CellGrid - Visualization data composed of cells of arbitrary type.
    
    Superclass: DataObject
    
    CellGrid inherits DataObject in order to introduce the concept
    of cells that, instead of relying on spatial points to specify their
    shape, rely on degrees of freedom (which may or may not be embedded
    in a world coordinate system).
    
    The degrees of freedom that define cells and the functions using
    those cells as their domain are provided in data arrays. The arrays
    are partitioned into groups (vtkdata_set_attributes) by the registered
    cell types. Each array in a group has the same number of tuples.
    
    @sa DataObject DataSetAttributes
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkCellGrid, obj, update, **traits)
    
    def _get_shape_attribute(self):
        return wrap_vtk(self._vtk_obj.GetShapeAttribute())
    def _set_shape_attribute(self, arg):
        old_val = self._get_shape_attribute()
        self._wrap_call(self._vtk_obj.SetShapeAttribute,
                        deref_vtk(arg))
        self.trait_property_changed('shape_attribute', old_val, arg)
    shape_attribute = traits.Property(_get_shape_attribute, _set_shape_attribute, desc=\
        r"""
        Set/get the "shape attribute" (i.e., a vector-valued
        cell-attribute that maps from reference to world coordinates).
        
        If there is no shape attribute, then a CellGrid cannot be
        rendered.
        
        A shape attribute must have between 1 and 4 components
        (inclusive).
        
        If you call set_shape_attribute with an attribute that does not
        satisfy this constraint, this method will return false and have
        no effect. If you wish to "remove" a grid's shape, call
        set_shape_attribute(nullptr).
        """
    )

    def get_bounds(self, *args):
        """
        get_bounds(self, bounds:[float, float, float, float, float, float])
             -> None
        C++: void get_bounds(double bounds[6])
        Fill the provided bounding box with the bounds of all the cells
        present in the grid.
        
        If no cells are present, the bounding box will be reset to
        uninitialized bounds. It is up to each cell type to implement a
        specialization of the bounds_query operation.
        
        The bounds are ordered { -x, +x, -y, +y, -z, +z }.
        """
        ret = self._wrap_call(self._vtk_obj.GetBounds, *args)
        return ret

    def get_cell_attribute_by_id(self, *args):
        """
        get_cell_attribute_by_id(self, attributeId:int) -> CellAttribute
        C++: CellAttribute *get_cell_attribute_by_id(int attributeId)
        Return an attribute given its name or identifier.
        
        This is currently an O(n) process, but additional indices could
        be added internally if needed.
        
        These methods may return a null pointer if no such attribute
        exists.
        
        Multiple attributes with the same name are possible. The first
        match will be returned.
        """
        ret = self._wrap_call(self._vtk_obj.GetCellAttributeById, *args)
        return wrap_vtk(ret)

    def get_cell_attribute_by_name(self, *args):
        """
        get_cell_attribute_by_name(self, name:str) -> CellAttribute
        C++: CellAttribute *get_cell_attribute_by_name(
            const std::string &name)"""
        ret = self._wrap_call(self._vtk_obj.GetCellAttributeByName, *args)
        return wrap_vtk(ret)

    def get_cell_type(self, *args):
        """
        get_cell_type(self, cellTypeName:StringToken) -> CellMetadata
        C++: CellMetadata *get_cell_type(StringToken cellTypeName)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.GetCellType, *my_args)
        return wrap_vtk(ret)

    def _get_number_of_cells(self):
        return self._vtk_obj.GetNumberOfCells()
    number_of_cells = traits.Property(_get_number_of_cells, desc=\
        r"""
        Return the number of cells (of all types).
        """
    )

    def add_cell_attribute(self, *args):
        """
        add_cell_attribute(self, attribute:CellAttribute) -> bool
        C++: virtual bool add_cell_attribute(CellAttribute *attribute)
        Add a cell-attribute to the dataset. A cell-attribute is an
        object representing a consistent collection of arrays that
        specify a function over the entire CellGrid's domain (i.e.,
        all cells of all types present in the CellGrid), with custom
        storage available to each cell type to facilitate interpolation,
        rendering, and other basic visualization operations.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.AddCellAttribute, *my_args)
        return ret

    def add_cell_metadata(self, *args):
        """
        add_cell_metadata(self, cellType:CellMetadata) -> CellMetadata
        C++: CellMetadata *add_cell_metadata(CellMetadata *cellType)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.AddCellMetadata, *my_args)
        return wrap_vtk(ret)

    def find_attributes(self, *args):
        """
        find_attributes(self, type:int) -> DataSetAttributes
        C++: DataSetAttributes *find_attributes(int type)"""
        ret = self._wrap_call(self._vtk_obj.FindAttributes, *args)
        return wrap_vtk(ret)

    def query(self, *args):
        """
        query(self, query:CellGridQuery) -> bool
        C++: bool query(CellGridQuery *query)
        Perform a query on all the cells in this instance.
        
        The return value indicates success (true when all cells respond
        to the query) or failure (false when some cell type is unable to
        handle the query).
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.Query, *my_args)
        return ret

    _updateable_traits_ = \
    (('global_release_data_flag', 'GetGlobalReleaseDataFlag'), ('debug',
    'GetDebug'), ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_release_data_flag', 'global_warning_display',
    'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(CellGrid, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit CellGrid properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['global_release_data_flag'], [], ['object_name']),
            title='Edit CellGrid properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit CellGrid properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

