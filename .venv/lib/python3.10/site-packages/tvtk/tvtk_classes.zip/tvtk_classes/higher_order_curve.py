# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.non_linear_cell import NonLinearCell


class HigherOrderCurve(NonLinearCell):
    r"""
    HigherOrderCurve
    
    Superclass: NonLinearCell
    
    See Also:
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkHigherOrderCurve, obj, update, **traits)
    
    parametric_coords = traits.Array(enter_set=True, auto_set=False, shape=(6,), dtype="float", value=(0.0, 0.0, 0.0, 1.0, 0.0, 0.0), cols=3, desc=\
        r"""
        
        """
    )

    def _parametric_coords_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetParametricCoords,
                        self.parametric_coords)

    def _get_order(self):
        return self._vtk_obj.GetOrder()
    order = traits.Property(_get_order, desc=\
        r"""
        
        """
    )

    def get_order(self, *args):
        """
        get_order(self) -> Pointer
        C++: const int *get_order()
        get_order(self, i:int) -> int
        C++: int get_order(int i)"""
        ret = self._wrap_call(self._vtk_obj.GetOrder, *args)
        return ret

    def point_count_supports_uniform_order(self, *args):
        """
        point_count_supports_uniform_order(pointsPerCell:int) -> bool
        C++: static bool point_count_supports_uniform_order(
            IdType pointsPerCell)
        Return true if the number of points supports a cell of uniform
        degree along each axis.
        
        For curves, this is trivially true when pointsper_cell >= 2.
        """
        ret = self._wrap_call(self._vtk_obj.PointCountSupportsUniformOrder, *args)
        return ret

    def point_index_from_ijk(self, *args):
        """
        point_index_from_ijk(self, i:int, __b:int, __c:int) -> int
        C++: int point_index_from_ijk(int i, int, int)"""
        ret = self._wrap_call(self._vtk_obj.PointIndexFromIJK, *args)
        return ret

    def sub_cell_coordinates_from_id(self, *args):
        """
        sub_cell_coordinates_from_id(self, ijk:Vector3i, subId:int) -> bool
        C++: bool sub_cell_coordinates_from_id(Vector3i &ijk, int subId)
        sub_cell_coordinates_from_id(self, i:int, subId:int) -> bool
        C++: bool sub_cell_coordinates_from_id(int &i, int subId)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SubCellCoordinatesFromId, *my_args)
        return ret

    def transform_approx_to_cell_params(self, *args):
        """
        transform_approx_to_cell_params(self, subCell:int, pcoords:[float,
            ...]) -> bool
        C++: bool transform_approx_to_cell_params(int subCell,
            double *pcoords)"""
        ret = self._wrap_call(self._vtk_obj.TransformApproxToCellParams, *args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('parametric_coords',
    'GetParametricCoords'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name',
    'parametric_coords'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(HigherOrderCurve, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit HigherOrderCurve properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name', 'parametric_coords']),
            title='Edit HigherOrderCurve properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit HigherOrderCurve properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

