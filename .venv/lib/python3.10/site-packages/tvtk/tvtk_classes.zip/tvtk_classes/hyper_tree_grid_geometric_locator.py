# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.hyper_tree_grid_locator import HyperTreeGridLocator


class HyperTreeGridGeometricLocator(HyperTreeGridLocator):
    r"""
    HyperTreeGridGeometricLocator - class that implements accelerated
    searches through hyper_tree Grids (HTGs) using geometric information
    
    Superclass: HyperTreeGridLocator
    
    The goal of this class is to implement a geometric locator search
    through the HTG structure. Its main feature should be to expose a
    generic interface to finding the HTG cells that contain a given
    geometric object. The search through the HTG is implemented using a
    HyperTreeGridNonOrientedGeometricCursor. The arborescent structure
    of the HTG should be sufficient to accelerate the search and achieve
    good performance in general.
    
    All methods in this class should be thread safe since it is meant to
    be used in a multi-threaded environment out of the box (except set_htg
    which should be called outside any multi-threaded setting).
    
    @sa
    HyperTreeGridLocator, HyperTreeGrid, HyperTree,
    HyperTreeGridOrientedCursor, HyperTreeGridNonOrientedCursor
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkHyperTreeGridGeometricLocator, obj, update, **traits)
    
    def _get_htg(self):
        return wrap_vtk(self._vtk_obj.GetHTG())
    def _set_htg(self, arg):
        old_val = self._get_htg()
        self._wrap_call(self._vtk_obj.SetHTG,
                        deref_vtk(arg))
        self.trait_property_changed('htg', old_val, arg)
    htg = traits.Property(_get_htg, _set_htg, desc=\
        r"""
        Getter/Setter methods for setting the HyperTreeGrid
        """
    )

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('tolerance', 'GetTolerance'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name', 'tolerance'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(HyperTreeGridGeometricLocator, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit HyperTreeGridGeometricLocator properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name', 'tolerance']),
            title='Edit HyperTreeGridGeometricLocator properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit HyperTreeGridGeometricLocator properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

