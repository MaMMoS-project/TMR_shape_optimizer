# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.image_algorithm import ImageAlgorithm


class ImageEllipsoidSource(ImageAlgorithm):
    r"""
    ImageEllipsoidSource - Create a binary image of an ellipsoid.
    
    Superclass: ImageAlgorithm
    
    ImageEllipsoidSource creates a binary image of a ellipsoid.  It
    was created as an example of a simple source, and to test the mask
    filter. It is also used internally in ImageDilateErode3D.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkImageEllipsoidSource, obj, update, **traits)
    
    def get_output_scalar_type(self):
        """
        get_output_scalar_type(self) -> int
        C++: virtual int get_output_scalar_type()"""
        ret = self._vtk_obj.GetOutputScalarType()
        return ret
        

    def set_output_scalar_type(self, *args):
        """
        set_output_scalar_type(self, _arg:int) -> None
        C++: virtual void set_output_scalar_type(int _arg)
        Set what type of scalar data this source should generate.
        """
        ret = self._wrap_call(self._vtk_obj.SetOutputScalarType, *args)
        return ret

    def set_output_scalar_type_to_char(self):
        """
        set_output_scalar_type_to_char(self) -> None
        C++: void set_output_scalar_type_to_char()"""
        self._vtk_obj.SetOutputScalarTypeToChar()

    def set_output_scalar_type_to_double(self):
        """
        set_output_scalar_type_to_double(self) -> None
        C++: void set_output_scalar_type_to_double()"""
        self._vtk_obj.SetOutputScalarTypeToDouble()

    def set_output_scalar_type_to_float(self):
        """
        set_output_scalar_type_to_float(self) -> None
        C++: void set_output_scalar_type_to_float()"""
        self._vtk_obj.SetOutputScalarTypeToFloat()

    def set_output_scalar_type_to_int(self):
        """
        set_output_scalar_type_to_int(self) -> None
        C++: void set_output_scalar_type_to_int()"""
        self._vtk_obj.SetOutputScalarTypeToInt()

    def set_output_scalar_type_to_long(self):
        """
        set_output_scalar_type_to_long(self) -> None
        C++: void set_output_scalar_type_to_long()"""
        self._vtk_obj.SetOutputScalarTypeToLong()

    def set_output_scalar_type_to_short(self):
        """
        set_output_scalar_type_to_short(self) -> None
        C++: void set_output_scalar_type_to_short()"""
        self._vtk_obj.SetOutputScalarTypeToShort()

    def set_output_scalar_type_to_unsigned_char(self):
        """
        set_output_scalar_type_to_unsigned_char(self) -> None
        C++: void set_output_scalar_type_to_unsigned_char()"""
        self._vtk_obj.SetOutputScalarTypeToUnsignedChar()

    def set_output_scalar_type_to_unsigned_int(self):
        """
        set_output_scalar_type_to_unsigned_int(self) -> None
        C++: void set_output_scalar_type_to_unsigned_int()"""
        self._vtk_obj.SetOutputScalarTypeToUnsignedInt()

    def set_output_scalar_type_to_unsigned_long(self):
        """
        set_output_scalar_type_to_unsigned_long(self) -> None
        C++: void set_output_scalar_type_to_unsigned_long()"""
        self._vtk_obj.SetOutputScalarTypeToUnsignedLong()

    def set_output_scalar_type_to_unsigned_short(self):
        """
        set_output_scalar_type_to_unsigned_short(self) -> None
        C++: void set_output_scalar_type_to_unsigned_short()"""
        self._vtk_obj.SetOutputScalarTypeToUnsignedShort()

    center = traits.Array(enter_set=True, auto_set=False, shape=(3,), dtype="float", value=(128.0, 128.0, 0.0), cols=3, desc=\
        r"""
        Set/Get the center of the ellipsoid.
        """
    )

    def _center_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetCenter,
                        self.center)

    in_value = traits.Float(255.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the inside pixel values.
        """
    )

    def _in_value_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetInValue,
                        self.in_value)

    out_value = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the outside pixel values.
        """
    )

    def _out_value_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetOutValue,
                        self.out_value)

    radius = traits.Array(enter_set=True, auto_set=False, shape=(3,), dtype="float", value=(70.0, 70.0, 70.0), cols=3, desc=\
        r"""
        Set/Get the radius of the ellipsoid.
        """
    )

    def _radius_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRadius,
                        self.radius)

    whole_extent = traits.Array(enter_set=True, auto_set=False, shape=(6,), dtype="int", value=(0, 255, 0, 255, 0, 0), cols=3, desc=\
        r"""
        Set/Get the extent of the whole output image.
        """
    )

    def _whole_extent_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetWholeExtent,
                        self.whole_extent)

    def _get_input(self):
        try:
            return wrap_vtk(self._vtk_obj.GetInput(0))
        except TypeError:
            return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input,
                            desc="The first input of this object, i.e. the result of `get_input(0)`.")
    
    def get_input(self, *args):
        """
        get_input(self, port:int) -> DataObject
        C++: DataObject *get_input(int port)
        get_input(self) -> DataObject
        C++: DataObject *get_input()
        Get a data object for one of the input port connections.  The use
        of this method is strongly discouraged, but some filters that
        were written a long time ago still use this method.
        """
        ret = self._wrap_call(self._vtk_obj.GetInput, *args)
        return wrap_vtk(ret)

    _updateable_traits_ = \
    (('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('center',
    'GetCenter'), ('in_value', 'GetInValue'), ('out_value',
    'GetOutValue'), ('radius', 'GetRadius'), ('whole_extent',
    'GetWholeExtent'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'release_data_flag', 'abort_output', 'center', 'in_value',
    'object_name', 'out_value', 'progress_text', 'radius',
    'whole_extent'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(ImageEllipsoidSource, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit ImageEllipsoidSource properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['abort_output', 'center', 'in_value', 'object_name',
            'out_value', 'radius', 'whole_extent']),
            title='Edit ImageEllipsoidSource properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit ImageEllipsoidSource properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

