# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class URI(Object):
    r"""
    URI - URI representation
    
    Superclass: Object
    
    This class is final and immutable.
    - Use `URI::Parse` to create an URI from its string
      representation.
    - Use `to_string` to get the string representation from an URI.
    - Use `URI::Make` to create an URI from components directly.
    - Use `URI::Resolve` to merge two URIs.
    - Use `URI::Clone` or member `Clone` if you need to copy an URI.
    
    Other functions are mainly getters for URI components or URI type
    identification.
    
    Known limitations:
    - No [normalized comparison
      support](https://datatracker.ietf.org/doc/html/rfc3986#section-6.1)
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkURI, obj, update, **traits)
    
    def _get_authority(self):
        return wrap_vtk(self._vtk_obj.GetAuthority())
    authority = traits.Property(_get_authority, desc=\
        r"""
        URI authority.
        """
    )

    def _get_fragment(self):
        return wrap_vtk(self._vtk_obj.GetFragment())
    fragment = traits.Property(_get_fragment, desc=\
        r"""
        URI fragment.
        """
    )

    def _get_path(self):
        return wrap_vtk(self._vtk_obj.GetPath())
    path = traits.Property(_get_path, desc=\
        r"""
        URI path.
        """
    )

    def _get_query(self):
        return wrap_vtk(self._vtk_obj.GetQuery())
    query = traits.Property(_get_query, desc=\
        r"""
        URI query.
        """
    )

    def _get_scheme(self):
        return wrap_vtk(self._vtk_obj.GetScheme())
    scheme = traits.Property(_get_scheme, desc=\
        r"""
        URI scheme.
        """
    )

    def clone(self, *args):
        """
        clone(other:URI) -> URI
        C++: static SmartPointer<vtkURI> clone(const URI *other)
        clone(self) -> URI
        C++: SmartPointer<vtkURI> clone()
        Clone a URI
        
        @param other URI to clone
        @return if `other == nullptr` returns nullptr, otherwise returns
            a new URI
        with the exact same components as `other`
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.Clone, *my_args)
        return wrap_vtk(ret)

    def is_absolute(self):
        """
        is_absolute(self) -> bool
        C++: bool is_absolute()"""
        ret = self._vtk_obj.IsAbsolute()
        return ret
        

    def is_empty(self):
        """
        is_empty(self) -> bool
        C++: bool is_empty()"""
        ret = self._vtk_obj.IsEmpty()
        return ret
        

    def is_full(self):
        """
        is_full(self) -> bool
        C++: bool is_full()"""
        ret = self._vtk_obj.IsFull()
        return ret
        

    def is_reference(self):
        """
        is_reference(self) -> bool
        C++: bool is_reference()
        URI types determination
        
        URI can be either:
        - A full
          [URI](https://datatracker.ietf.org/doc/html/rfc3986#section-3):
          It has a scheme.
        - an [URI
          reference](https://datatracker.ietf.org/doc/html/rfc3986#section
          -4.1): an URI that is either a relative reference or a full
          URI.
        - a [relative
          reference](https://datatracker.ietf.org/doc/html/rfc3986#section
          -4.2), an URI that refers to data that has to be resolved from
          a base URI prior to loading. It does not define a scheme but
          defines at least one other component.
        - an [absolute
          URI](https://datatracker.ietf.org/doc/html/rfc3986#section-4.3),
           an URI that can be used as a base URI. It defines a scheme and
        no fragment. It may define other components.
        - a [same-document
          reference](https://datatracker.ietf.org/doc/html/rfc3986#section
          -4.4): an URI that defines only a fragment.
        - An empty URI
        """
        ret = self._vtk_obj.IsReference()
        return ret
        

    def is_relative(self):
        """
        is_relative(self) -> bool
        C++: bool is_relative()"""
        ret = self._vtk_obj.IsRelative()
        return ret
        

    def is_same_doc_ref(self):
        """
        is_same_doc_ref(self) -> bool
        C++: bool is_same_doc_ref()"""
        ret = self._vtk_obj.IsSameDocRef()
        return ret
        

    def parse(self, *args):
        """
        parse(uri:str) -> URI
        C++: static SmartPointer<vtkURI> parse(const std::string &uri)
        parse(uri:str, size:int) -> URI
        C++: static SmartPointer<vtkURI> parse(const char *uri,
            std::size_t size)
        Create a new URI from a string.
        
        Perform as if by calling `URI::Parse(uri.data(), uri.size())`.
        
        @param uri the URI string representation, may be empty.
        @return nullptr if URI syntax checks do not pass, otherwise a new
        URI.
        """
        ret = self._wrap_call(self._vtk_obj.Parse, *args)
        return wrap_vtk(ret)

    def percent_decode(self, *args):
        """
        percent_decode(str:str) -> str
        C++: static std::string percent_decode(const std::string &str)
        percent_decode(str:str, size:int) -> str
        C++: static std::string percent_decode(const char *str,
            std::size_t size)
        Calls `percent_decode(str.data(), str.size())`
        
        @param str Input string to decode, may be empty.
        @return Decoded string from `str`
        """
        ret = self._wrap_call(self._vtk_obj.PercentDecode, *args)
        return ret

    def percent_encode(self, *args):
        """
        percent_encode(str:str) -> str
        C++: static std::string percent_encode(const std::string &str)
        percent_encode(str:str, size:int) -> str
        C++: static std::string percent_encode(const char *str,
            std::size_t size)
        Calls `percent_encode(str.data(), str.size())`
        
        @param str Input string to encode, may be empty.
        @return Encodes string from `str`
        """
        ret = self._wrap_call(self._vtk_obj.PercentEncode, *args)
        return ret

    def resolve(self, *args):
        """
        resolve(baseURI:URI, uri:URI) -> URI
        C++: static SmartPointer<vtkURI> resolve(const URI *baseURI,
             const URI *uri)
        Resolve an URI from a base URI
        
        This implements
        [RFC3986](https://datatracker.ietf.org/doc/html/rfc3986#section-5)
        . Base URI are used to compose absolute URIs from relative
        reference.
        
        @param baseURI the base URI, if nullptr, this function only
            checks if `uri` is a complete URI
        @param uri relative reference that needs to be resolved from
            `baseURI`
        @return nullptr if URI syntax checks do not pass, otherwise a new
        URI.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.Resolve, *my_args)
        return wrap_vtk(ret)

    def to_string(self):
        """
        to_string(self) -> str
        C++: std::string to_string()
        Contruct the string representation of the URI
        
        @return a string representing the URI
        """
        ret = self._vtk_obj.ToString()
        return ret
        

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(URI, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit URI properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name']),
            title='Edit URI properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit URI properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

