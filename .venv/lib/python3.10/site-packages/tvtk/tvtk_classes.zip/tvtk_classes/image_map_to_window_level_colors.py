# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.image_map_to_colors import ImageMapToColors


class ImageMapToWindowLevelColors(ImageMapToColors):
    r"""
    ImageMapToWindowLevelColors - Map an image through a lookup table
    and/or a window/level.
    
    Superclass: ImageMapToColors
    
    The ImageMapToWindowLevelColors filter can be used to perform the
    following operations depending on its settings:
    -# If no lookup table is provided, and if the input data has a single
       component (any numerical scalar type is allowed), then the data is
       mapped through the specified Window/Level.  The type of the output
       scalars will be "unsigned char" with a range of (0,255).
    -# If no lookup table is provided, and if the input data is already
       unsigned char, and if the Window/Level is set to 255.0/127.5, then
       the input data will be passed directly to the output.
    -# If a lookup table is provided, then the first component of the
       input data is mapped through the lookup table (using the Range of
       the lookup table), and the resulting color is modulated according
       to the Window/Level.  For example, if the input value is 500 and
       the Window/Level are 2000/1000, the output value will be RGB*0.25
       where RGB is the color assigned by the lookup table and 0.25 is
       the modulation factor. See set_window() and set_level() for the
       equations used for modulation. To map scalars through a lookup
       table without modulating the resulting color, use
       ImageMapToColors instead of this filter.
    @sa
    LookupTable ScalarsToColors
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkImageMapToWindowLevelColors, obj, update, **traits)
    
    level = traits.Float(127.5, enter_set=True, auto_set=False, desc=\
        r"""
        Set / Get the Level to use -> modulation will be performed on the
        color based on (S - (L - W/2))/W where S is the scalar value, L
        is the level and W is the window.
        """
    )

    def _level_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetLevel,
                        self.level)

    window = traits.Float(255.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set / Get the Window to use -> modulation will be performed on
        the color based on (S - (L - W/2))/W where S is the scalar value,
        L is the level and W is the window.
        """
    )

    def _window_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetWindow,
                        self.window)

    def _get_input(self):
        try:
            return wrap_vtk(self._vtk_obj.GetInput(0))
        except TypeError:
            return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input,
                            desc="The first input of this object, i.e. the result of `get_input(0)`.")
    
    def get_input(self, *args):
        """
        get_input(self, port:int) -> DataObject
        C++: DataObject *get_input(int port)
        get_input(self) -> DataObject
        C++: DataObject *get_input()
        Get a data object for one of the input port connections.  The use
        of this method is strongly discouraged, but some filters that
        were written a long time ago still use this method.
        """
        ret = self._wrap_call(self._vtk_obj.GetInput, *args)
        return wrap_vtk(ret)

    _updateable_traits_ = \
    (('pass_alpha_to_output', 'GetPassAlphaToOutput'), ('abort_execute',
    'GetAbortExecute'), ('release_data_flag', 'GetReleaseDataFlag'),
    ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('output_format', 'GetOutputFormat'),
    ('split_mode', 'GetSplitMode'), ('level', 'GetLevel'), ('window',
    'GetWindow'), ('active_component', 'GetActiveComponent'),
    ('na_n_color', 'GetNaNColor'), ('desired_bytes_per_piece',
    'GetDesiredBytesPerPiece'), ('enable_smp', 'GetEnableSMP'),
    ('global_default_enable_smp', 'GetGlobalDefaultEnableSMP'),
    ('minimum_piece_size', 'GetMinimumPieceSize'), ('number_of_threads',
    'GetNumberOfThreads'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'pass_alpha_to_output', 'release_data_flag', 'output_format',
    'split_mode', 'abort_output', 'active_component',
    'desired_bytes_per_piece', 'enable_smp', 'global_default_enable_smp',
    'level', 'minimum_piece_size', 'na_n_color', 'number_of_threads',
    'object_name', 'progress_text', 'window'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(ImageMapToWindowLevelColors, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit ImageMapToWindowLevelColors properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['pass_alpha_to_output'], ['output_format', 'split_mode'],
            ['abort_output', 'active_component', 'desired_bytes_per_piece',
            'enable_smp', 'global_default_enable_smp', 'level',
            'minimum_piece_size', 'na_n_color', 'number_of_threads',
            'object_name', 'window']),
            title='Edit ImageMapToWindowLevelColors properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit ImageMapToWindowLevelColors properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

