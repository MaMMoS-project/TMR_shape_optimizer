# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class CellAttribute(Object):
    r"""
    CellAttribute - A function defined over the physical domain of a
    CellGrid.
    
    Superclass: Object
    
    This is a base class for attributes (functions) defined on the space
    discretized by a CellGrid. A CellAttribute class must handle
    cells of all types present in the grid.
    
    @sa CellGrid
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkCellAttribute, obj, update, **traits)
    
    def _get_colormap(self):
        return wrap_vtk(self._vtk_obj.GetColormap())
    def _set_colormap(self, arg):
        old_val = self._get_colormap()
        self._wrap_call(self._vtk_obj.SetColormap,
                        deref_vtk(arg))
        self.trait_property_changed('colormap', old_val, arg)
    colormap = traits.Property(_get_colormap, _set_colormap, desc=\
        r"""
        
        """
    )

    id = traits.Int(-1, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _id_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetId,
                        self.id)

    def _get_attribute_type(self):
        return wrap_vtk(self._vtk_obj.GetAttributeType())
    attribute_type = traits.Property(_get_attribute_type, desc=\
        r"""
        Return a (user-presentable) type for this attribute.
        
        The type should reflect the nature of the function and may
        reflect the nature of the cell shapes supported.
        
        The type is distinct from the space in which values reside;
        instead it describes the mathematical technique used to
        interpolate values (e.g., "rational spline", "polynomial", "partition of
        unity", "stochastic", etc.), behavior at cell boundaries, and
        other relevant information. For example, a quadratic field that
        allows discontinuities at cell boundaries and uses Lagrange
        interpolation of arbitrary order (i.e., order may differ per
        cell) might return "discontinuous Lagrange polynomial arbitrary
        order".
        
        Currently, this is just a free-form string but in the future we
        may adopt a more rigorous standard.
        """
    )

    def _get_name(self):
        return wrap_vtk(self._vtk_obj.GetName())
    name = traits.Property(_get_name, desc=\
        r"""
        Return the (user-presentable) name of this attribute.
        """
    )

    def _get_number_of_components(self):
        return self._vtk_obj.GetNumberOfComponents()
    number_of_components = traits.Property(_get_number_of_components, desc=\
        r"""
        Return the number of components this function provides at each
        point in space.
        
        This should be consistent with the value returned by get_space().
        """
    )

    def _get_space(self):
        return wrap_vtk(self._vtk_obj.GetSpace())
    space = traits.Property(_get_space, desc=\
        r"""
        Return a token identifying the space containing all field values.
        
        Currently, this is just a free-form string but in the future we
        may adopt a more rigorous standard.
        
        Some suggested values + "ℝ¹" – single (scalar) values over
        the real numbers. + "ℝ¹+" – single (scalar) values over the
        non-negative real numbers. + "ℝ²" – 2-d vector values over
        the real numbers. + "ℝ³" – 3-d vector values over the real
        numbers. + "𝕊³" – points inside a unit 3-dimensional ball.
        + "S²" – points on the surface of a unit 3-dimensional sphere.
        + "SO(3)" – rotation matrices. + "SU(2)" – special unitary
        group (homeomorphic to SO(3)).
        
        Note that the space might imply the number of components but it
        also specifies how users should interpret operations such as
        addition and/or multipliciation, especially in the case of
        transforms applied to the domain.
        """
    )

    def initialize(self, *args):
        """
        initialize(self, name:StringToken,
            attributeType:StringToken, space:StringToken,
            numberOfComponents:int) -> bool
        C++: virtual bool initialize(StringToken name,
            StringToken attributeType, StringToken space,
            int numberOfComponents)
        Initialize an attribute.
        
        Never call this method after a cell-attribute has been inserted
        into an unordered container as it will change the reported hash,
        which can cause crashes later.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.Initialize, *my_args)
        return ret

    def shallow_copy(self, *args):
        """
        shallow_copy(self, other:CellAttribute) -> None
        C++: virtual void shallow_copy(CellAttribute *other)
        Copy data from an other attribute instance into this instance.
        
        Currently, the only difference between shallow and deep copies is
        that the colormap is copied by reference when shallow-copying and
        a cloned instance is created when deep-copying.
        
        Note that the list of array pointers is copied by reference (even
        when deep-copying a CellAttribute) unless you provide
        deep_copy() with a map of arrayRewrites pointers. The CellGrid
        owns the arrays, not the CellAttribute, so the when
        deep-copying a CellGrid, it will have a map of array copies it
        has created. If any arrays is mentioned in all_arrays and is not
        present in arrayRewrites, it is copied by reference.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.ShallowCopy, *my_args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('id', 'GetId'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'id', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(CellAttribute, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit CellAttribute properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['id', 'object_name']),
            title='Edit CellAttribute properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit CellAttribute properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

