# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.gl2ps_exporter import GL2PSExporter


class OpenGLGL2PSExporter(GL2PSExporter):
    r"""
    OpenGLGL2PSExporter - open_gl2 implementation of Gl2ps exporter.
    
    Superclass: GL2PSExporter
    
    Implementation of GL2PSExporter for the open_gl2 backend.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkOpenGLGL2PSExporter, obj, update, **traits)
    
    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    def _set_input(self, arg):
        old_val = self._get_input()
        self._wrap_call(self._vtk_obj.SetInput,
                        deref_vtk(arg))
        self.trait_property_changed('input', old_val, arg)
    input = traits.Property(_get_input, _set_input, desc=\
        r"""
        
        """
    )

    _updateable_traits_ = \
    (('best_root', 'GetBestRoot'), ('compress', 'GetCompress'),
    ('draw_background', 'GetDrawBackground'), ('landscape',
    'GetLandscape'), ('occlusion_cull', 'GetOcclusionCull'),
    ('ps3_shading', 'GetPS3Shading'), ('silent', 'GetSilent'),
    ('simple_line_offset', 'GetSimpleLineOffset'), ('text_as_path',
    'GetTextAsPath'), ('text', 'GetText'),
    ('write3d_props_as_raster_image', 'GetWrite3DPropsAsRasterImage'),
    ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('file_format', 'GetFileFormat'), ('sort',
    'GetSort'), ('buffer_size', 'GetBufferSize'), ('file_prefix',
    'GetFilePrefix'), ('line_width_factor', 'GetLineWidthFactor'),
    ('point_size_factor', 'GetPointSizeFactor'), ('title', 'GetTitle'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['best_root', 'compress', 'debug', 'draw_background',
    'global_warning_display', 'landscape', 'occlusion_cull',
    'ps3_shading', 'silent', 'simple_line_offset', 'text', 'text_as_path',
    'write3d_props_as_raster_image', 'file_format', 'sort', 'buffer_size',
    'file_prefix', 'line_width_factor', 'object_name',
    'point_size_factor', 'title'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(OpenGLGL2PSExporter, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit OpenGLGL2PSExporter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['best_root', 'compress', 'draw_background', 'landscape',
            'occlusion_cull', 'ps3_shading', 'silent', 'simple_line_offset',
            'text', 'text_as_path', 'write3d_props_as_raster_image'],
            ['file_format', 'sort'], ['buffer_size', 'file_prefix',
            'line_width_factor', 'object_name', 'point_size_factor', 'title']),
            title='Edit OpenGLGL2PSExporter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit OpenGLGL2PSExporter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

