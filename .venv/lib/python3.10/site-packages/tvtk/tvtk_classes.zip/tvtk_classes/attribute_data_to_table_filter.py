# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.table_algorithm import TableAlgorithm


class AttributeDataToTableFilter(TableAlgorithm):
    r"""
    AttributeDataToTableFilter - this filter produces a Table from
    the chosen attribute in the input data object.
    
    Superclass: TableAlgorithm
    
    AttributeDataToTableFilter is a filter that produces a Table
    from the chosen attribute in the input dataobject. This filter can
    accept composite datasets. If the input is a composite dataset, the
    output is a multiblock with Table leaves.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkAttributeDataToTableFilter, obj, update, **traits)
    
    add_meta_data = tvtk_base.false_bool_trait(desc=\
        r"""
        It is possible for this filter to add additional meta-data to the
        field data such as point coordinates (when point attributes are
        selected and input is pointset) or structured coordinates etc. To
        enable this addition of extra information, turn this flag on. Off
        by default.
        """
    )

    def _add_meta_data_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAddMetaData,
                        self.add_meta_data_)

    generate_cell_connectivity = tvtk_base.false_bool_trait(desc=\
        r"""
        When set to true (default is false) the connectivity of each cell
        will be added by adding a new column for each point.
        """
    )

    def _generate_cell_connectivity_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetGenerateCellConnectivity,
                        self.generate_cell_connectivity_)

    generate_original_ids = tvtk_base.false_bool_trait(desc=\
        r"""
        When set (default) the OriginalIndices array will be added to
        the output. Can be overridden by setting this flag to 0. This is
        only respected when add_meta_data is true.
        """
    )

    def _generate_original_ids_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetGenerateOriginalIds,
                        self.generate_original_ids_)

    field_association = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        Select the attribute type. Accepted values are
        \li DataObject::FIELD_ASSOCIATION_POINTS,
        \li DataObject::FIELD_ASSOCIATION_CELLS,
        \li DataObject::FIELD_ASSOCIATION_NONE,
        \li DataObject::FIELD_ASSOCIATION_VERTICES,
        \li DataObject::FIELD_ASSOCIATION_EDGES,
        \li DataObject::FIELD_ASSOCIATION_ROWS
        If value is DataObject::FIELD_ASSOCIATION_NONE, then field_data
        associated with the input dataobject is extracted.
        
        Default is DataObject::FIELD_ASSOCIATION_POINTS
        """
    )

    def _field_association_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetFieldAssociation,
                        self.field_association)

    _updateable_traits_ = \
    (('add_meta_data', 'GetAddMetaData'), ('generate_cell_connectivity',
    'GetGenerateCellConnectivity'), ('generate_original_ids',
    'GetGenerateOriginalIds'), ('abort_execute', 'GetAbortExecute'),
    ('release_data_flag', 'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('field_association', 'GetFieldAssociation'), ('abort_output',
    'GetAbortOutput'), ('progress_text', 'GetProgressText'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'add_meta_data', 'debug',
    'generate_cell_connectivity', 'generate_original_ids',
    'global_warning_display', 'release_data_flag', 'abort_output',
    'field_association', 'object_name', 'progress_text'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(AttributeDataToTableFilter, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit AttributeDataToTableFilter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['add_meta_data', 'generate_cell_connectivity',
            'generate_original_ids'], [], ['abort_output', 'field_association',
            'object_name']),
            title='Edit AttributeDataToTableFilter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit AttributeDataToTableFilter properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

